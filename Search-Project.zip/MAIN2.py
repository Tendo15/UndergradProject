 import requests
# from pprint import pprint

# define global variables
app_id = 'c55ea9f8'
app_key = '38bb8f106818f3d0891a8d6c6df0a34e'

# define function to request data from API
def recipe_search(ingredient):
    result = requests.get('https://api.edamam.com/search?q={}&app_id={}&app_key={}'.format(ingredient, app_id, app_key))
    data = result.json()
    return data['hits']  # hits result of all data for the recipe and nutritional info

# define function to output desired results based on user inputs
def output_results():
    # get user input for ingredient variable
    ingredient = input('Enter ingredient: ')

    # define results for output_results function
    results = recipe_search(ingredient)
    #print(results) # to test she says to remove when testing

    # setting up dietary options using list (in this case probably easiest to provide a list to choose from to ensure valid options)
    diet_options = ['Vegan', 'Vegetarian', 'Pescatarian', 'Gluten-Free']
    # user input to confirm dietary requirement status
    diet_requirement = input('Do you have a dietary requirement or preference (yes/no)? :')
    # further user input from diet_options required while dietary_requirement == 'yes'
    while diet_requirement == 'yes':
        diet_requirement = input(f'choose your requirement from the options (Case Sensitive):) \n{diet_options}')

    # convert user input to title case for health labels
    diet_requirement = diet_requirement.title()

    # Evaluate if user has specified a valid dietary requirement to using boolean logic
    if diet_requirement in diet_options:
        diet_requirement_flag = 1
    else:
        diet_requirement_flag = 0

    # OPTION 1: DIETARY REQS
    if diet_requirement_flag == 1:
        # create blank list to store recipe dictionaries
        recipe_results_dietary = []
        # for loop to iterate through api results
        for result in results:
            recipe = result['recipe']

            # define variables for requested recipe data
            recipe_name = recipe['label']
            recipe_url = recipe['url']
            dietary_requirement = recipe['healthLabels']

            for label in dietary_requirement:
                # healthLabels in Title case, so need to convert to Title
                if label == diet_requirement:
                    # create dictionary for individual recipe data inc dietary req labels
                    recipe_data = {
                        'recipe_name': recipe_name,
                        'url': recipe_url,
                        'dietary_requirement': dietary_requirement
                    }

                    # append results to recipe_results_cuisine list
                    recipe_results_dietary.append(recipe_data)

        print(recipe_results_dietary)

    # OPTION 2: NO DIETARY REQS
    elif diet_requirement_flag == 0:
        # create blank list to store recipe dictionaries
        recipe_results_noreqs = []

        for result in results:
            recipe = result['recipe']

            # define variables for requested recipe data
            recipe_name = recipe['label']
            recipe_url = recipe['url']

            # create dictionary for individual recipe data inc cuisine type and dietary req labels
            recipe_data = {
                'recipe_name': recipe_name,
                'url': recipe_url,
                }

            # append results to recipe_results_cuisine list
            recipe_results_noreqs.append(recipe_data)

        print(recipe_results_noreqs)

output_results()