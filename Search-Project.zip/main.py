import requests
from pprint import pprint


def recipe_search(ingredient):
  app_id = 'c55ea9f8'
  app_key = '38bb8f106818f3d0891a8d6c6df0a34e'

  result = requests.get(
    'https://api.edamam.com/search?q={}&app_id={}&app_key={}'.format(
      ingredient, app_id, app_key))
  data = result.json()
  # example with chocolate to make sure it exists in the api https://api.edamam.com/search?q=chocolate&app_id=c55ea9f8&app_key=38bb8f106818f3d0891a8d6c6df0a34e

  return data[
    'hits']  # hits result of all data for the recipe and nutritional info


ingredient = input(
  'Enter ingredient: '
)  # this is here so its defined for all functions (used later when we save ingredients in a file in the extended version)

# Extension: save results in file FinalProject_results.txt

with open('FinalProject_results.txt', 'a') as FinalProject_file:
  new_result = ingredient
  FinalProject_file.write(new_result + "\n")


def run():
  results = recipe_search(ingredient)
  for result in results:
    recipe = result['recipe']

    print(recipe['label'])
    print(recipe['url'])
    print()


run()

# extension recipe choice calories

recipe_choice = input('What recipe would you like to know the calories from the list above? ')

def run(recipe_choice):
    results = recipe_search(recipe_choice)
    for result in results:
        recipe = result['recipe']

        print(recipe['calories'])
        # print(recipe['FoodCategory'])
        # pprint(recipe['totalNutrients'])


run(recipe_choice)

#extetion: asking the user additional questions

ingredient_choice = input('what type of ingredient?')

#

#tried extending with an if statement
healthy_ingrediant = ingredient and ingredient_choice
if run():
  result = ['vegan']
  print('healthy ingredient choice')

else:
  print('unhealthy ingredient choice')
